import tkinter
from tkinter import font

root = tkinter.Tk()
list_fonts = list(font.families())
print(list_fonts)